import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Leaf, Star, Beaker, Heart } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const ingredients = [
  {
    id: '1',
    name: 'Wheat Protein',
    category: 'Protein',
    origin: 'Organic farms in France',
    benefits: ['Strengthens hair', 'Repairs damage', 'Adds shine', 'Moisturizes'],
    description: 'A natural protein derived from wheat that helps strengthen and repair damaged hair while providing essential moisture.',
    usage: 'Featured in our GLOHA Shampoo line for its proven strengthening properties.',
    rating: 4.9,
    relatedProducts: ['GLOHA Shampoo'],
  },
  {
    id: '2',
    name: 'Argan Oil',
    category: 'Oil',
    origin: 'Morocco',
    benefits: ['Deep moisturizing', 'Frizz control', 'UV protection', 'Antioxidant rich'],
    description: 'Cold-pressed from Moroccan argan nuts, this precious oil provides deep nourishment and protection.',
    usage: 'Key ingredient in our Hair Oil formulation for ultimate hydration.',
    rating: 4.8,
    relatedProducts: ['GLOHA Hair Oil'],
  },
  {
    id: '3',
    name: 'Green Tea Extract',
    category: 'Antioxidant',
    origin: 'Japan',
    benefits: ['Antioxidant protection', 'Scalp health', 'Growth stimulation', 'Anti-inflammatory'],
    description: 'Rich in polyphenols and catechins, green tea extract protects and revitalizes hair and scalp.',
    usage: 'Incorporated across our product line for its protective and soothing properties.',
    rating: 4.7,
    relatedProducts: ['GLOHA Shampoo', 'GLOHA Hair Oil'],
  },
  {
    id: '4',
    name: 'Coconut Oil',
    category: 'Oil',
    origin: 'Philippines',
    benefits: ['Deep conditioning', 'Protein loss prevention', 'Shine enhancement', 'Natural SPF'],
    description: 'Virgin coconut oil penetrates hair shaft to prevent protein loss and provide deep conditioning.',
    usage: 'Essential component in our nourishing Hair Oil blend.',
    rating: 4.6,
    relatedProducts: ['GLOHA Hair Oil'],
  },
  {
    id: '5',
    name: 'Aloe Vera Extract',
    category: 'Botanical',
    origin: 'Mexico',
    benefits: ['Soothing', 'Moisturizing', 'pH balancing', 'Scalp healing'],
    description: 'Pure aloe vera extract provides gentle soothing and healing properties for sensitive scalps.',
    usage: 'Used in our gentle formulations for its calming and moisturizing effects.',
    rating: 4.8,
    relatedProducts: ['GLOHA Shampoo'],
  },
];

const categories = ['All', 'Protein', 'Oil', 'Antioxidant', 'Botanical', 'Vitamin'];

export default function Ingredients() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedIngredient, setSelectedIngredient] = useState<null | typeof ingredients[0]>(null);

  const filteredIngredients = ingredients.filter(ingredient => {
    const matchesSearch = ingredient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ingredient.benefits.some(benefit => 
                           benefit.toLowerCase().includes(searchQuery.toLowerCase())
                         );
    const matchesCategory = selectedCategory === 'All' || ingredient.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-hero py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-bold text-foreground mb-6">
              Ingredients & Science
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Discover the powerful botanical ingredients that make our products effective. 
              Each ingredient is carefully selected for its proven benefits and sustainable sourcing.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search ingredients or benefits..."
                className="pl-10"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Ingredients List */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="grid gap-6"
            >
              {filteredIngredients.map((ingredient, index) => (
                <motion.div
                  key={ingredient.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card 
                    className="p-6 hover:shadow-botanical transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedIngredient(ingredient)}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-heading font-semibold text-foreground mb-1">
                          {ingredient.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Origin: {ingredient.origin}
                        </p>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium">{ingredient.rating}</span>
                      </div>
                    </div>

                    <p className="text-muted-foreground mb-4">
                      {ingredient.description}
                    </p>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {ingredient.benefits.slice(0, 3).map((benefit) => (
                        <Badge key={benefit} variant="secondary">
                          {benefit}
                        </Badge>
                      ))}
                      {ingredient.benefits.length > 3 && (
                        <Badge variant="outline">
                          +{ingredient.benefits.length - 3} more
                        </Badge>
                      )}
                    </div>

                    <div className="flex items-center justify-between">
                      <Badge className="bg-primary/10 text-primary">
                        {ingredient.category}
                      </Badge>
                      <Button variant="ghost" size="sm">
                        Learn More
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </motion.div>

            {filteredIngredients.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-16"
              >
                <Leaf className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg text-muted-foreground mb-4">
                  No ingredients found matching your search.
                </p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                  }}
                >
                  Clear Filters
                </Button>
              </motion.div>
            )}
          </div>

          {/* Ingredient Detail Panel */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="sticky top-24"
            >
              {selectedIngredient ? (
                <Card className="p-6">
                  <div className="flex items-center space-x-2 mb-4">
                    <Beaker className="h-5 w-5 text-primary" />
                    <h3 className="text-lg font-heading font-semibold">
                      {selectedIngredient.name}
                    </h3>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Origin</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedIngredient.origin}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Benefits</h4>
                      <div className="space-y-1">
                        {selectedIngredient.benefits.map((benefit) => (
                          <div key={benefit} className="flex items-center space-x-2">
                            <Heart className="h-3 w-3 text-primary" />
                            <span className="text-sm text-muted-foreground">{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Usage</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedIngredient.usage}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Featured In</h4>
                      <div className="space-y-1">
                        {selectedIngredient.relatedProducts.map((product) => (
                          <Badge key={product} variant="outline">
                            {product}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Effectiveness Rating</span>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="font-semibold">{selectedIngredient.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ) : (
                <Card className="p-6 text-center">
                  <Leaf className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-heading font-semibold text-foreground mb-2">
                    Select an Ingredient
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Click on any ingredient to learn more about its benefits and usage.
                  </p>
                </Card>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}