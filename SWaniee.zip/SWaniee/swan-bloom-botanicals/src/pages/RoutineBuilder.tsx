import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronLeft, Sparkles, Check, Clock, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';

const quizSteps = [
  {
    id: 'hair-type',
    title: 'What\'s your hair type?',
    subtitle: 'Help us understand your hair\'s natural characteristics',
    options: [
      { id: 'straight', label: 'Straight', description: 'Hair lies flat against the scalp' },
      { id: 'wavy', label: 'Wavy', description: 'Hair has a slight wave pattern' },
      { id: 'curly', label: 'Curly', description: 'Hair forms defined curls' },
      { id: 'coily', label: 'Coily', description: 'Hair has tight curls or coils' },
    ],
  },
  {
    id: 'concerns',
    title: 'What are your main hair concerns?',
    subtitle: 'Select all that apply',
    multiple: true,
    options: [
      { id: 'dryness', label: 'Dryness', description: 'Hair feels dry and brittle' },
      { id: 'damage', label: 'Damage', description: 'Split ends, breakage, or chemical damage' },
      { id: 'frizz', label: 'Frizz', description: 'Hair is unmanageable and frizzy' },
      { id: 'oily-scalp', label: 'Oily Scalp', description: 'Scalp gets greasy quickly' },
      { id: 'thinning', label: 'Thinning', description: 'Hair appears thin or lacking volume' },
      { id: 'color-treated', label: 'Color-Treated', description: 'Hair is colored or chemically treated' },
    ],
  },
  {
    id: 'goals',
    title: 'What are your hair goals?',
    subtitle: 'What would you like to achieve?',
    multiple: true,
    options: [
      { id: 'strength', label: 'Strengthen Hair', description: 'Reduce breakage and improve resilience' },
      { id: 'moisture', label: 'Add Moisture', description: 'Hydrate and nourish dry hair' },
      { id: 'shine', label: 'Enhance Shine', description: 'Get glossy, healthy-looking hair' },
      { id: 'volume', label: 'Boost Volume', description: 'Add body and fullness' },
      { id: 'growth', label: 'Promote Growth', description: 'Support healthy hair growth' },
      { id: 'manageability', label: 'Improve Manageability', description: 'Make hair easier to style' },
    ],
  },
  {
    id: 'budget',
    title: 'What\'s your budget preference?',
    subtitle: 'Help us recommend the right products for you',
    options: [
      { id: 'essential', label: 'Essential ($25-50)', description: 'Core products for basic routine' },
      { id: 'complete', label: 'Complete ($50-100)', description: 'Full routine with targeted treatments' },
      { id: 'premium', label: 'Premium ($100+)', description: 'Comprehensive care with luxury products' },
    ],
  },
];

const routineRecommendations = {
  morning: [
    {
      id: '1',
      name: 'GLOHA Shampoo',
      step: 'Cleanse',
      description: 'Gently cleanse with wheat protein',
      time: '2-3 times per week',
      image: '/lovable-uploads/27e2108c-559b-4aa6-8c0a-478419d5a285.png',
    },
  ],
  evening: [
    {
      id: '2',
      name: 'GLOHA Hair Oil',
      step: 'Nourish',
      description: 'Deep nourishment with 18+ herbs',
      time: '2-3 times per week',
      image: '/lovable-uploads/d51b7f4c-1009-4920-bc6e-61ef8a99ed10.png',
    },
  ],
};

export default function RoutineBuilder() {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [showResults, setShowResults] = useState(false);

  const currentQuiz = quizSteps[currentStep];
  const isLastStep = currentStep === quizSteps.length - 1;

  const handleAnswer = (questionId: string, value: string | string[]) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: value,
    }));
  };

  const handleNext = () => {
    if (isLastStep) {
      setShowResults(true);
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => prev - 1);
  };

  const canProceed = () => {
    const answer = answers[currentQuiz.id];
    if (currentQuiz.multiple) {
      return Array.isArray(answer) && answer.length > 0;
    }
    return answer !== undefined;
  };

  const resetQuiz = () => {
    setCurrentStep(0);
    setAnswers({});
    setShowResults(false);
  };

  if (showResults) {
    return (
      <div className="min-h-screen bg-background">
        <section className="bg-gradient-hero py-16">
          <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-botanical rounded-full mb-6">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-4">
                Your Personalized Routine
              </h1>
              <p className="text-lg text-muted-foreground">
                Based on your answers, we've created a custom routine just for you.
              </p>
            </motion.div>
          </div>
        </section>

        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Morning Routine */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Card className="p-6">
                <div className="flex items-center space-x-2 mb-6">
                  <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                    <span className="text-yellow-600 text-sm">☀️</span>
                  </div>
                  <h2 className="text-xl font-heading font-semibold">Morning Routine</h2>
                </div>

                <div className="space-y-4">
                  {routineRecommendations.morning.map((product, index) => (
                    <div key={product.id} className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-semibold">
                        {index + 1}
                      </div>
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground">{product.name}</h3>
                        <p className="text-sm text-muted-foreground mb-1">{product.description}</p>
                        <div className="flex items-center space-x-2">
                          <Clock className="w-3 h-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{product.time}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>

            {/* Evening Routine */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Card className="p-6">
                <div className="flex items-center space-x-2 mb-6">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 text-sm">🌙</span>
                  </div>
                  <h2 className="text-xl font-heading font-semibold">Evening Routine</h2>
                </div>

                <div className="space-y-4">
                  {routineRecommendations.evening.map((product, index) => (
                    <div key={product.id} className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-semibold">
                        {index + 1}
                      </div>
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground">{product.name}</h3>
                        <p className="text-sm text-muted-foreground mb-1">{product.description}</p>
                        <div className="flex items-center space-x-2">
                          <Clock className="w-3 h-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{product.time}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-8 text-center"
          >
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="botanical-gradient hover:opacity-90">
                Add Full Routine to Cart - $60.00
              </Button>
              <Button variant="outline" size="lg" onClick={resetQuiz}>
                Retake Quiz
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <section className="bg-gradient-hero py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-4">
              Build Your Perfect Routine
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Answer a few questions to get personalized product recommendations.
            </p>
            
            {/* Progress Bar */}
            <div className="max-w-md mx-auto">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-muted-foreground">Progress</span>
                <span className="text-sm text-muted-foreground">
                  {currentStep + 1} of {quizSteps.length}
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <motion.div
                  className="bg-gradient-botanical h-2 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentStep + 1) / quizSteps.length) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="p-8">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-heading font-bold text-foreground mb-2">
                  {currentQuiz.title}
                </h2>
                <p className="text-muted-foreground">
                  {currentQuiz.subtitle}
                </p>
              </div>

              <div className="space-y-4">
                {currentQuiz.multiple ? (
                  // Multiple choice (checkboxes)
                  <div className="space-y-3">
                    {currentQuiz.options.map((option) => (
                      <div key={option.id} className="flex items-start space-x-3 p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors">
                        <Checkbox
                          id={option.id}
                          checked={(answers[currentQuiz.id] as string[] || []).includes(option.id)}
                          onCheckedChange={(checked) => {
                            const currentAnswers = (answers[currentQuiz.id] as string[]) || [];
                            if (checked) {
                              handleAnswer(currentQuiz.id, [...currentAnswers, option.id]);
                            } else {
                              handleAnswer(currentQuiz.id, currentAnswers.filter(id => id !== option.id));
                            }
                          }}
                        />
                        <div className="flex-1">
                          <Label htmlFor={option.id} className="text-base font-medium cursor-pointer">
                            {option.label}
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1">
                            {option.description}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  // Single choice (radio buttons)
                  <RadioGroup
                    value={answers[currentQuiz.id] as string}
                    onValueChange={(value) => handleAnswer(currentQuiz.id, value)}
                  >
                    <div className="space-y-3">
                      {currentQuiz.options.map((option) => (
                        <div key={option.id} className="flex items-start space-x-3 p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors">
                          <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                          <div className="flex-1">
                            <Label htmlFor={option.id} className="text-base font-medium cursor-pointer">
                              {option.label}
                            </Label>
                            <p className="text-sm text-muted-foreground mt-1">
                              {option.description}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </RadioGroup>
                )}
              </div>

              <div className="flex justify-between items-center mt-8">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentStep === 0}
                  className="flex items-center"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>

                <Button
                  onClick={handleNext}
                  disabled={!canProceed()}
                  className="flex items-center"
                >
                  {isLastStep ? 'Get My Routine' : 'Next'}
                  {!isLastStep && <ChevronRight className="w-4 h-4 ml-2" />}
                  {isLastStep && <Sparkles className="w-4 h-4 ml-2" />}
                </Button>
              </div>
            </Card>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}