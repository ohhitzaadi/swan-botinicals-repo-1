import { motion } from 'framer-motion';
import { ArrowRight, Leaf, Award, Heart, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { Link } from 'react-router-dom';

const featuredProducts = [
  {
    id: '1',
    name: 'GLOHA Shampoo',
    description: 'The Benefit of Wheat Protein - Gently cleanses, moisturizes the scalp, promotes healthy hair growth',
    price: '$28.00',
    image: '/lovable-uploads/27e2108c-559b-4aa6-8c0a-478419d5a285.png',
    rating: 4.8,
    reviews: 124,
    tags: ['Wheat Protein', 'Sulfate Free'],
    isBestseller: true,
  },
  {
    id: '2',
    name: 'GLOHA Hair Oil',
    description: 'The Benefit of 18+ Herbs - 6 Carrier Oils, 5 Essential Oils, 2 Vitamins for ultimate nourishment',
    price: '$32.00',
    image: '/lovable-uploads/d51b7f4c-1009-4920-bc6e-61ef8a99ed10.png',
    rating: 4.9,
    reviews: 89,
    tags: ['18+ Herbs', 'Essential Oils'],
    isNew: true,
  },
];

const features = [
  {
    icon: Leaf,
    title: 'Natural Ingredients',
    description: 'Carefully sourced botanical ingredients for maximum efficacy and purity.',
  },
  {
    icon: Award,
    title: 'Premium Quality',
    description: 'Rigorously tested formulations that deliver exceptional results.',
  },
  {
    icon: Heart,
    title: 'Gentle & Effective',
    description: 'Suitable for all hair types with no harsh chemicals or sulfates.',
  },
  {
    icon: Sparkles,
    title: 'Proven Results',
    description: 'Trusted by thousands for healthier, more beautiful hair.',
  },
];

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center bg-gradient-hero overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-transparent to-primary/10"></div>
        
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left"
            >
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-4xl sm:text-5xl lg:text-6xl font-heading font-bold text-foreground mb-6"
              >
                Natural Beauty,{' '}
                <span className="text-gradient">
                  Botanical Power
                </span>
              </motion.h1>
              
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-xl text-muted-foreground mb-8 max-w-lg"
              >
                Discover Swan Botanicals' premium collection of natural haircare and skincare products. 
                Crafted with botanical ingredients for healthier, more beautiful you.
              </motion.p>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
              >
                <Button size="lg" className="botanical-gradient hover:opacity-90 transition-opacity text-white">
                  Shop Collection
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" size="lg" className="border-rose text-rose hover:bg-rose-muted">
                  Take Routine Quiz
                </Button>
              </motion.div>
            </motion.div>

            {/* Hero Image */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative"
            >
              <div className="relative aspect-square max-w-lg mx-auto">
                <motion.img
                  src="/lovable-uploads/27e2108c-559b-4aa6-8c0a-478419d5a285.png"
                  alt="GLOHA Shampoo"
                  className="w-full h-full object-contain"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                />
                <div className="absolute -inset-4 bg-gradient-botanical opacity-20 blur-3xl rounded-full"></div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-6 h-10 border-2 border-primary rounded-full flex justify-center"
          >
            <div className="w-1 h-3 bg-primary rounded-full mt-2"></div>
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-4">
              Why Choose Swan Botanicals?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the difference of premium botanical ingredients backed by science.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <div className={`h-16 w-16 mx-auto mb-6 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 ${
                  index % 2 === 0 ? 'bg-gradient-botanical' : 'rose-gradient'
                }`}>
                  <feature.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-heading font-semibold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-4">
              Featured Products
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover our best-selling GLOHA collection, formulated with powerful botanical ingredients.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <Button size="lg" variant="outline" className="hover:bg-accent">
              <Link to="/shop" className="flex items-center">
                View All Products
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Brand Story Section */}
      <section className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-6">
                Our Botanical Journey
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Swan Botanicals was born from a passion for harnessing nature's power to create 
                effective, sustainable beauty solutions. Every product is carefully crafted with 
                premium botanical ingredients sourced from around the world.
              </p>
              <p className="text-lg text-muted-foreground mb-8">
                From wheat protein to 18+ herb blends, our formulations are designed to nourish, 
                strengthen, and beautify your hair naturally.
              </p>
              <Button variant="outline" size="lg" className="hover:bg-accent">
                <Link to="/about" className="flex items-center">
                  Learn Our Story
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-4"
            >
              <div className="space-y-4">
                <img
                  src="/lovable-uploads/4c8eaad0-c317-498c-b8ca-d175f0ecc4e2.png"
                  alt="Swan Botanicals Product Collection"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
                <img
                  src="/lovable-uploads/16a26754-2386-49f9-98f1-21dbc07bf715.png"
                  alt="GLOHA Shampoo Blue Background"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
              </div>
              <div className="space-y-4 mt-8">
                <img
                  src="/lovable-uploads/2967488e-488f-4deb-97a3-ecbcaef627d1.png"
                  alt="GLOHA Shampoo Lifestyle"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
                <img
                  src="/lovable-uploads/485cfc02-b169-422c-a11b-551436c83d7e.png"
                  alt="Natural Ingredients"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 rose-gradient text-white">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl font-heading font-bold mb-6">
              Ready to Transform Your Hair?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Let our AI Routine Concierge create a personalized haircare routine just for you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-rose hover:bg-white/90 transition-colors">
                Start Routine Quiz
                <Sparkles className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                Browse Products
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}