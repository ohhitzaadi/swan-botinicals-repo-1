import { motion } from 'framer-motion';
import { Leaf, Heart, Award, Users, Target, Globe } from 'lucide-react';

const values = [
  {
    icon: Leaf,
    title: 'Natural Ingredients',
    description: 'We source the finest botanical ingredients from sustainable farms worldwide, ensuring purity and potency in every product.',
  },
  {
    icon: Heart,
    title: 'Gentle Care',
    description: 'Our formulations are designed to be gentle yet effective, suitable for all hair and skin types without compromising on results.',
  },
  {
    icon: Award,
    title: 'Premium Quality',
    description: 'Every product undergoes rigorous testing and quality control to meet our high standards for excellence.',
  },
  {
    icon: Globe,
    title: 'Sustainability',
    description: 'We are committed to sustainable practices, from eco-friendly packaging to responsible sourcing.',
  },
];

const milestones = [
  {
    year: '2018',
    title: 'Foundation',
    description: 'Swan Botanicals was founded with a vision to create premium natural beauty products.',
  },
  {
    year: '2020',
    title: 'GLOHA Launch',
    description: 'Launched our flagship GLOHA line with innovative wheat protein technology.',
  },
  {
    year: '2022',
    title: 'Expansion',
    description: 'Expanded our product range with 18+ herb formulations and essential oils.',
  },
  {
    year: '2024',
    title: 'Innovation',
    description: 'Introduced AI-powered routine personalization and sustainable packaging.',
  },
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-hero py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-bold text-foreground mb-6">
              Our Botanical Story
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Swan Botanicals represents the perfect harmony between nature's wisdom and modern beauty science. 
              We believe that the most effective beauty solutions come from the earth's finest botanical ingredients.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img
                src="/lovable-uploads/4c8eaad0-c317-498c-b8ca-d175f0ecc4e2.png"
                alt="Swan Botanicals Collection"
                className="w-full rounded-xl shadow-elegant"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div>
                <h2 className="text-3xl font-heading font-bold text-foreground mb-4">
                  Our Mission
                </h2>
                <p className="text-lg text-muted-foreground">
                  To create premium natural beauty products that harness the power of botanical ingredients, 
                  providing effective and gentle solutions for healthy hair and skin. We are committed to 
                  sustainability, quality, and the well-being of our customers and the planet.
                </p>
              </div>

              <div>
                <h2 className="text-3xl font-heading font-bold text-foreground mb-4">
                  Our Vision
                </h2>
                <p className="text-lg text-muted-foreground">
                  To be the leading brand in natural beauty, inspiring people worldwide to embrace the 
                  power of botanical ingredients. We envision a future where beauty and sustainability 
                  go hand in hand, creating products that are good for you and good for the earth.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-4">
              Our Values
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              These core principles guide everything we do, from product development to customer care.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <div className="card-gradient p-8 rounded-xl shadow-soft hover:shadow-botanical transition-all duration-300">
                  <div className="h-16 w-16 mx-auto mb-6 bg-gradient-botanical rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <value.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-heading font-semibold text-foreground mb-3">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {value.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Sustainability */}
      <section id="sustainability" className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground">
                Committed to Sustainability
              </h2>
              <p className="text-lg text-muted-foreground">
                We believe that beauty should never come at the expense of our planet. Our commitment 
                to sustainability is woven into every aspect of our business, from ingredient sourcing 
                to packaging design.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-0.5">
                    <div className="h-2 w-2 rounded-full bg-white"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Eco-Friendly Packaging</h4>
                    <p className="text-muted-foreground">
                      Our bottles are made from recycled materials and are fully recyclable.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-0.5">
                    <div className="h-2 w-2 rounded-full bg-white"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Sustainable Sourcing</h4>
                    <p className="text-muted-foreground">
                      We partner with certified organic farms and suppliers who share our values.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-0.5">
                    <div className="h-2 w-2 rounded-full bg-white"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Carbon Neutral Shipping</h4>
                    <p className="text-muted-foreground">
                      We offset the carbon footprint of all our shipments through verified programs.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-4"
            >
              <div className="space-y-4">
                <img
                  src="/lovable-uploads/485cfc02-b169-422c-a11b-551436c83d7e.png"
                  alt="Natural ingredients and stone texture"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
                <img
                  src="/lovable-uploads/2967488e-488f-4deb-97a3-ecbcaef627d1.png"
                  alt="GLOHA product in natural setting"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
              </div>
              <div className="space-y-4 mt-8">
                <img
                  src="/lovable-uploads/16a26754-2386-49f9-98f1-21dbc07bf715.png"
                  alt="Sustainable packaging"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
                <img
                  src="/lovable-uploads/d51b7f4c-1009-4920-bc6e-61ef8a99ed10.png"
                  alt="Natural hair oil"
                  className="w-full rounded-lg shadow-soft hover-lift"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Journey Timeline */}
      <section className="py-24 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-4">
              Our Journey
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From humble beginnings to becoming a trusted name in natural beauty.
            </p>
          </motion.div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gradient-botanical"></div>
            <div className="space-y-16">
              {milestones.map((milestone, index) => (
                <motion.div
                  key={milestone.year}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className={`flex items-center ${
                    index % 2 === 0 ? 'justify-start' : 'justify-end'
                  }`}
                >
                  <div className={`w-5/12 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                    <div className="card-gradient p-6 rounded-xl shadow-soft">
                      <div className="text-2xl font-bold text-primary mb-2">
                        {milestone.year}
                      </div>
                      <h3 className="text-xl font-heading font-semibold text-foreground mb-2">
                        {milestone.title}
                      </h3>
                      <p className="text-muted-foreground">
                        {milestone.description}
                      </p>
                    </div>
                  </div>
                  <div className="absolute left-1/2 transform -translate-x-1/2 h-4 w-4 bg-primary rounded-full border-4 border-background"></div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-6">
              Meet Our Team
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
              Our passionate team of botanists, chemists, and beauty experts work tirelessly to create 
              products that deliver exceptional results while staying true to our natural principles.
            </p>
            
            <div className="flex items-center justify-center space-x-8 text-muted-foreground">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">50+</div>
                <div className="text-sm">Team Members</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">15+</div>
                <div className="text-sm">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">100K+</div>
                <div className="text-sm">Happy Customers</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}