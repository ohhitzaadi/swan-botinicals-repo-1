import { useState } from 'react';
import { motion } from 'framer-motion';
import { Filter, Search, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ProductCard } from '@/components/ProductCard';
import { Card } from '@/components/ui/card';

const allProducts = [
  {
    id: '1',
    name: 'GLOHA Shampoo',
    description: 'The Benefit of Wheat Protein - Gently cleanses, moisturizes the scalp, promotes healthy hair growth',
    price: '$28.00',
    image: '/lovable-uploads/27e2108c-559b-4aa6-8c0a-478419d5a285.png',
    rating: 4.8,
    reviews: 124,
    tags: ['Wheat Protein', 'Sulfate Free'],
    isBestseller: true,
    category: 'haircare',
    concerns: ['dry-hair', 'damage'],
  },
  {
    id: '2',
    name: 'GLOHA Hair Oil',
    description: 'The Benefit of 18+ Herbs - 6 Carrier Oils, 5 Essential Oils, 2 Vitamins for ultimate nourishment',
    price: '$32.00',
    image: '/lovable-uploads/d51b7f4c-1009-4920-bc6e-61ef8a99ed10.png',
    rating: 4.9,
    reviews: 89,
    tags: ['18+ Herbs', 'Essential Oils'],
    isNew: true,
    category: 'haircare',
    concerns: ['dry-hair', 'frizz'],
  },
  {
    id: '3',
    name: 'GLOHA Shampoo (300ml)',
    description: 'Premium size of our bestselling wheat protein shampoo for extended use',
    price: '$28.00',
    image: '/lovable-uploads/94f4e049-6225-495d-8775-96ec85e85f1f.png',
    rating: 4.8,
    reviews: 256,
    tags: ['Wheat Protein', 'Value Size'],
    category: 'haircare',
    concerns: ['dry-hair', 'damage'],
  },
];

const categories = [
  { id: 'all', label: 'All Products' },
  { id: 'haircare', label: 'Haircare' },
  { id: 'skincare', label: 'Skincare' },
];

const concerns = [
  { id: 'dry-hair', label: 'Dry Hair' },
  { id: 'damage', label: 'Damaged Hair' },
  { id: 'frizz', label: 'Frizz Control' },
  { id: 'oily-scalp', label: 'Oily Scalp' },
  { id: 'sensitive', label: 'Sensitive Scalp' },
];

const priceRanges = [
  { id: 'under-25', label: 'Under $25' },
  { id: '25-50', label: '$25 - $50' },
  { id: '50-75', label: '$50 - $75' },
  { id: 'over-75', label: 'Over $75' },
];

export default function Shop() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedConcerns, setSelectedConcerns] = useState<string[]>([]);
  const [selectedPriceRanges, setSelectedPriceRanges] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('featured');
  const [showFilters, setShowFilters] = useState(false);

  const filteredProducts = allProducts.filter(product => {
    // Search filter
    if (searchQuery && !product.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !product.description.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }

    // Category filter
    if (selectedCategory !== 'all' && product.category !== selectedCategory) {
      return false;
    }

    // Concerns filter
    if (selectedConcerns.length > 0) {
      const hasMatchingConcern = selectedConcerns.some(concern => 
        product.concerns?.includes(concern)
      );
      if (!hasMatchingConcern) return false;
    }

    return true;
  });

  const handleConcernChange = (concernId: string, checked: boolean) => {
    if (checked) {
      setSelectedConcerns([...selectedConcerns, concernId]);
    } else {
      setSelectedConcerns(selectedConcerns.filter(id => id !== concernId));
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-gradient-hero py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl sm:text-5xl font-heading font-bold text-foreground mb-4">
              Shop Natural Beauty
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover our complete collection of premium botanical haircare and skincare products.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className={`lg:w-1/4 ${showFilters ? 'block' : 'hidden lg:block'}`}
          >
            <Card className="p-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-heading font-semibold text-lg">Filters</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSelectedCategory('all');
                    setSelectedConcerns([]);
                    setSelectedPriceRanges([]);
                    setSearchQuery('');
                  }}
                >
                  Clear All
                </Button>
              </div>

              {/* Search */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search products..."
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Categories */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Category</label>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <div key={category.id} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id={category.id}
                        name="category"
                        checked={selectedCategory === category.id}
                        onChange={() => setSelectedCategory(category.id)}
                        className="text-primary"
                      />
                      <label htmlFor={category.id} className="text-sm">
                        {category.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Hair Concerns */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Hair Concerns</label>
                <div className="space-y-2">
                  {concerns.map((concern) => (
                    <div key={concern.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={concern.id}
                        checked={selectedConcerns.includes(concern.id)}
                        onCheckedChange={(checked) => 
                          handleConcernChange(concern.id, checked as boolean)
                        }
                      />
                      <label htmlFor={concern.id} className="text-sm">
                        {concern.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Price Range</label>
                <div className="space-y-2">
                  {priceRanges.map((range) => (
                    <div key={range.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={range.id}
                        checked={selectedPriceRanges.includes(range.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedPriceRanges([...selectedPriceRanges, range.id]);
                          } else {
                            setSelectedPriceRanges(selectedPriceRanges.filter(id => id !== range.id));
                          }
                        }}
                      />
                      <label htmlFor={range.id} className="text-sm">
                        {range.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Products */}
          <div className="lg:w-3/4">
            {/* Toolbar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8"
            >
              <div className="flex items-center gap-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                  className="lg:hidden"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                </Button>
                <p className="text-muted-foreground">
                  {filteredProducts.length} product{filteredProducts.length !== 1 ? 's' : ''} found
                </p>
              </div>

              <div className="flex items-center gap-4">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]">
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </motion.div>

            {/* Products Grid */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8"
            >
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </motion.div>

            {filteredProducts.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-16"
              >
                <p className="text-lg text-muted-foreground mb-4">
                  No products found matching your criteria.
                </p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedCategory('all');
                    setSelectedConcerns([]);
                    setSelectedPriceRanges([]);
                    setSearchQuery('');
                  }}
                >
                  Clear Filters
                </Button>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}