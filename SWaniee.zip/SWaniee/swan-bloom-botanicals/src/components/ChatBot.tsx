import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  products?: Array<{
    id: string;
    name: string;
    price: string;
    image: string;
  }>;
}

const initialMessages: Message[] = [
  {
    id: '1',
    type: 'bot',
    content: "Hi! I'm your AI Routine Concierge. I'll help you create the perfect haircare routine with Swan Botanicals products. Let's start with a few questions about your hair type and goals. What's your main hair concern?",
    timestamp: new Date(),
  },
];

const mockResponses = [
  {
    keywords: ['dry', 'damage', 'brittle'],
    response: "I understand you're dealing with dry, damaged hair. Our GLOHA Shampoo with wheat protein is perfect for strengthening and nourishing damaged hair. Would you like me to create a complete routine for dry hair repair?",
    products: [
      {
        id: '1',
        name: 'GLOHA Shampoo',
        price: '$28.00',
        image: '/lovable-uploads/27e2108c-559b-4aa6-8c0a-478419d5a285.png',
      },
    ],
  },
  {
    keywords: ['oily', 'greasy', 'scalp'],
    response: "For oily hair and scalp concerns, I recommend our gentle cleansing routine. The GLOHA Shampoo helps balance oil production while the Hair Oil can be used sparingly on ends only. Should I create a routine for oily hair management?",
    products: [
      {
        id: '1',
        name: 'GLOHA Shampoo',
        price: '$28.00',
        image: '/lovable-uploads/27e2108c-559b-4aa6-8c0a-478419d5a285.png',
      },
      {
        id: '2',
        name: 'GLOHA Hair Oil',
        price: '$32.00',
        image: '/lovable-uploads/d51b7f4c-1009-4920-bc6e-61ef8a99ed10.png',
      },
    ],
  },
  {
    keywords: ['routine', 'complete', 'yes', 'create'],
    response: "Perfect! Based on our conversation, I've created a personalized routine for you. Here's your recommended AM/PM routine with Swan Botanicals products:",
    products: [
      {
        id: '1',
        name: 'GLOHA Shampoo',
        price: '$28.00',
        image: '/lovable-uploads/27e2108c-559b-4aa6-8c0a-478419d5a285.png',
      },
      {
        id: '2',
        name: 'GLOHA Hair Oil',
        price: '$32.00',
        image: '/lovable-uploads/d51b7f4c-1009-4920-bc6e-61ef8a99ed10.png',
      },
    ],
  },
];

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI processing
    setTimeout(() => {
      const lowerInput = inputValue.toLowerCase();
      let response = mockResponses.find(r => 
        r.keywords.some(keyword => lowerInput.includes(keyword))
      );

      if (!response) {
        response = {
          keywords: [],
          response: "I'd love to help you find the perfect products! Could you tell me more about your specific hair concerns or what you're looking to achieve?",
          products: [],
        };
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: response.response,
        timestamp: new Date(),
        products: response.products,
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 2, type: "spring", stiffness: 260, damping: 20 }}
      >
        <Button
          onClick={() => setIsOpen(true)}
          className={cn(
            "h-14 w-14 rounded-full shadow-botanical",
            "bg-gradient-botanical hover:scale-105 transition-transform duration-200",
            isOpen && "hidden"
          )}
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="fixed bottom-6 right-6 z-50 w-80 sm:w-96"
          >
            <Card className="h-[500px] flex flex-col shadow-elegant">
              {/* Header */}
              <div className="p-4 border-b bg-gradient-botanical text-white rounded-t-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center">
                      <Sparkles className="h-4 w-4" />
                    </div>
                    <div>
                      <h3 className="font-semibold">AI Routine Concierge</h3>
                      <p className="text-xs opacity-90">Powered by Swan Botanicals</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsOpen(false)}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={cn(
                      "flex",
                      message.type === 'user' ? "justify-end" : "justify-start"
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[80%] p-3 rounded-lg text-sm",
                        message.type === 'user'
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      <p>{message.content}</p>
                      {message.products && message.products.length > 0 && (
                        <div className="mt-3 space-y-2">
                          {message.products.map((product) => (
                            <div
                              key={product.id}
                              className="flex items-center space-x-2 p-2 bg-white/50 rounded border"
                            >
                              <img
                                src={product.image}
                                alt={product.name}
                                className="h-10 w-10 object-cover rounded"
                              />
                              <div className="flex-1">
                                <p className="font-medium text-xs">{product.name}</p>
                                <p className="text-xs text-primary">{product.price}</p>
                              </div>
                            </div>
                          ))}
                          <Button size="sm" className="w-full mt-2">
                            Add Routine to Cart
                          </Button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
                
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex justify-start"
                  >
                    <div className="bg-muted p-3 rounded-lg">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-4 border-t">
                <div className="flex space-x-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask about your routine..."
                    className="flex-1"
                  />
                  <Button onClick={handleSend} disabled={!inputValue.trim() || isTyping}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}